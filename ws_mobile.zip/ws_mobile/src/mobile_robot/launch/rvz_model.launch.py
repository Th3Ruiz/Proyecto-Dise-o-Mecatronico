import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
import xacro

def generate_launch_description():
    # Nombre del paquete
    package_name = 'mobile_robot'
    
    # Ruta al archivo Xacro del modelo
    model_path = os.path.join(get_package_share_directory(package_name), 'model/robot.xacro')
    rviz_config_path = os.path.join(get_package_share_directory(package_name), 'rviz', 'modelo_robot.rviz')

    # Procesar el archivo Xacro
    robot_description = xacro.process_file(model_path).toxml()

    # Nodo para publicar el estado del robot
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description,
            'use_sim_time': True
        }]
    )

    # Nodo para lanzar RViz2
    rviz2_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config_path],
        parameters=[{'use_sim_time': True}]
    )

    return LaunchDescription([
        robot_state_publisher,
        rviz2_node
    ])