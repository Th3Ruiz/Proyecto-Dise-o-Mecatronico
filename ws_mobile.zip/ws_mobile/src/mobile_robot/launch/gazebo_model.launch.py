import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
import xacro

def generate_launch_description():
    
    robotXacroName = 'robot'
    package_name = 'mobile_robot'

    
    model_path = os.path.join(get_package_share_directory(package_name), 'model/robot.xacro')
    world_path = os.path.join(get_package_share_directory(package_name), 'model/empty_world.sdf')
    rviz_config_path = os.path.join(get_package_share_directory(package_name), 'config/robot.rviz')

   
    robot_description = xacro.process_file(model_path).toxml()

    
    gz_sim_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            get_package_share_directory('ros_gz_sim'),
            '/launch/gz_sim.launch.py'
        ]),
        launch_arguments={
            'gz_args': f'-r {world_path}'
        }.items()
    )


    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock',
            
            '/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
            
            
            '/model/robot/odometry@nav_msgs/msg/Odometry[gz.msgs.Odometry',
            
            
            '/joint_states@sensor_msgs/msg/JointState[gz.msgs.Model',
            
            
            '/tf@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V'
        ],
        output='screen'
    )

    
    spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-topic', 'robot_description',
            '-name', robotXacroName,
            '-x', '0.0',
            '-y', '0.0',
            '-z', '0.07',
            '-Y', '0.0',
            '-allow_renaming', 'true'
        ],
        output='screen'
    )

    
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description,
            'use_sim_time': True
        }]
    )

    
    #rviz2 = Node(
     #   package='rviz2',
      #  executable='rviz2',
       # name='rviz2',
        #arguments=['-d', rviz_config_path],
        #parameters=[{'use_sim_time': True}],
        #output='screen'
   # )

    
    teleop_twist_keyboard_node = Node(
        package='teleop_twist_keyboard',
        executable='teleop_twist_keyboard',
        prefix='xterm -e',
        output='screen',
        remappings=[('/cmd_vel', '/robot/cmd_vel')],
    )

    return LaunchDescription([
        gz_sim_launch,
        bridge,
        spawn_entity,
        robot_state_publisher,
      #  rviz2,
        # teleop_twist_keyboard_node  # Uncomment to enable keyboard control
    ])